package com.born1.service_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
